*********************************
features2d. 2D Features Framework
*********************************

.. highlight:: cpp

.. toctree::
    :maxdepth: 2

    feature_detection_and_description
    common_interfaces_of_feature_detectors
    common_interfaces_of_descriptor_extractors
    common_interfaces_of_descriptor_matchers
    common_interfaces_of_generic_descriptor_matchers
    drawing_function_of_keypoints_and_matches
    object_categorization
