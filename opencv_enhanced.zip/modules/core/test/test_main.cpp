#ifdef _MSC_VER
# if _MSC_VER >= 1700
#  pragma warning(disable:4447) // Disable warning 'main' signature found without threading model
# endif
#endif


#include "test_precomp.hpp"

CV_TEST_MAIN("cv")
