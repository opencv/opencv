****************************
core. The Core Functionality
****************************

.. toctree::
    :maxdepth: 2

    basic_structures
    old_basic_structures
    dynamic_structures
    operations_on_arrays
    drawing_functions
    xml_yaml_persistence
    old_xml_yaml_persistence
    clustering
    utility_and_system_functions_and_macros
    opengl_interop
