***************************************
contrib. Contributed/Experimental Stuff
***************************************

The module contains some recently added functionality that has not been stabilized, or functionality that is considered optional.

.. toctree::
    :maxdepth: 2

    stereo
    FaceRecognizer Documentation <facerec/index>
    Retina Documentation <retina/index>
    openfabmap
