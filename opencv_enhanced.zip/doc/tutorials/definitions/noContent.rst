
.. note::
   Unfortunately we have no tutorials into this section. And you can help us with that, since OpenCV is a community effort. If you have a tutorial suggestion or you have written a tutorial yourself (or coded a sample code) that you would like to see here, please follow these instructions: :ref:`howToWriteTutorial` and :how_to_contribute:`How to contribute <>`.
